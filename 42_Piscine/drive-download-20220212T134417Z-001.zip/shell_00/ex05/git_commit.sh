git log --pretty='%H' -5
