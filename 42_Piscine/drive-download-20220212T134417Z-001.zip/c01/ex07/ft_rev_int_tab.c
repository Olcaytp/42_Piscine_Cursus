/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otapan <otapan@student.42kocaeli.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/05 10:27:45 by otapan            #+#    #+#             */
/*   Updated: 2021/12/05 10:33:11 by otapan           ###   ########.tr       */
/*                                                                            */
/* ************************************************************************** */

void	(ft_rev_int_tab(int *tab, int size))
{
	int	index;
	int	index_end;
	int	empty;

	index = 0;
	index_end = 0;
	while (index < (size / 2))
	{
		empty = *(tab + index);
		*(tab + index) = *(tab + (size - index - 1));
		*(tab + (size - index - 1)) = empty;
		index++;
	}
}
