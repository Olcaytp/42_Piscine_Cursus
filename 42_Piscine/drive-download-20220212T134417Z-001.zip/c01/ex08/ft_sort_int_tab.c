/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: otapan <otapan@student.42kocaeli.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/01 15:27:49 by otapan            #+#    #+#             */
/*   Updated: 2021/12/05 10:35:07 by otapan           ###   ########.tr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size)
{
	int	i;
	int	j;
	int	empty;

	i = 1;
	while (i < size)
	{
		j = 0;
		while (j < size - i)
		{
			if (*(tab + j) > *(tab + j + 1))
			{
				empty = *(tab + j + 1);
				*(tab + j + 1) = *(tab + j);
				*(tab + j) = empty;
			}
			j++;
		}
		i++;
	}
}
